import { TestBed } from '@angular/core/testing';

import { UpdateIpoService } from './update-ipo.service';

describe('UpdateIpoService', () => {
  let service: UpdateIpoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UpdateIpoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
