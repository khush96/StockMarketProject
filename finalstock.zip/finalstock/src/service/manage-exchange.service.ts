import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { ManageExchange } from 'src/entity/ManageExchange';
import { Observable } from 'rxjs';

type EntityResponseType = HttpResponse<ManageExchange[]>;

@Injectable({
  providedIn: 'root'
})
export class ManageExchangeService {

  constructor(private http:HttpClient) { }

  getAllCompanyDetails():Observable<EntityResponseType>{
    return this.http.get<ManageExchange[]>("http://localhost:5516/stockExchangeDataFields", {observe: 'response'});
}

saveCompanyDetails(ManageExchange:ManageExchange){
   return this.http.post<ManageExchange>("http://localhost:5516/stockExchangeDataField", ManageExchange, {observe: 'response'});
}

}
