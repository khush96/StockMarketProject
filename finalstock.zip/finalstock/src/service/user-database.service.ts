import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserDatabaseModel } from 'src/entity/UserDatabase';

type EntityResponseType = HttpResponse<UserDatabaseModel[]>;

@Injectable({
  providedIn: 'root'
})
export class UserDatabaseService {

  constructor(private http:HttpClient) { }
  getAllUserDatabase():Observable<EntityResponseType>{
    //return this.http.get<UserDatabaseModel[]>("http://localhost:8084/userDatabase", {observe: 'response'});
    return this.http.get<UserDatabaseModel[]>("http://localhost:5515/userDatabases", {observe: 'response'});
}

saveUserDatabase(userDatabaseModel:UserDatabaseModel){
   return this.http.post<UserDatabaseModel>("http://localhost:5515/userDatabase", userDatabaseModel, {observe: 'response'});
}

}
