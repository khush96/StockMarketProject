import { Component, OnInit } from '@angular/core';
import { CompanyDetailsService } from 'src/service/company-details.service';
import { Router } from '@angular/router';
import { CompanyDetailsModel } from 'src/entity/CompanyDetails';

@Component({
  selector: 'app-barchart',
  templateUrl: './barchart.component.html',
  styleUrls: ['./barchart.component.css']
})
export class BarchartComponent implements OnInit {
  userDetails:CompanyDetailsModel[];
  a=[];
  
public barChartOptions = {
  scaleShowVerticalsLines: false,
  responsive: true
};
public barChartLabels = ['1000','2000','3000','4000','5000','6000','7000'];
public barChartType = 'bar';
public barChartLegend = 'true';
public barChartData = [
  {data: [1500, 2300, 4500, 5400, 1200, 1500, 4000], label: '1st Company'},
  {data: [2500, 790, 4000, 6100, 2600, 5400, 1000], label: '2nd Company'}
]  

  constructor(private service:CompanyDetailsService, private router: Router) { }
  ngOnInit(): void {

    this.service.getAllCompanyDetails().subscribe(data => {
      this.userDetails = data.body;
      console.log(data.body)
 });

  for(var i=0;i<this.userDetails.length;i++)
    {
      //  this.a[i]=this.userDetails[i].turn_over;
    }

  }
  
}