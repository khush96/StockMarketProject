import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExcelModel } from 'src/entity/ExcelModel';
import { ImportExcelService } from 'src/service/import-excel.service';
import { HttpResponse } from '@angular/common/http';
import { ExcelResponseModel } from 'src/entity/ExcelResponseModel';





@Component({
  selector: 'app-import-data',
  templateUrl: './import-data.component.html',
  styleUrls: ['./import-data.component.css']
})
export class ImportDataComponent implements OnInit {

  currentFileUpload: File;
  selectedFiles: FileList;
  excelDetails:ExcelModel[];

  excelsummary: ExcelResponseModel[];
  excelSumary1:ExcelResponseModel;

  constructor(private service:ImportExcelService,private router: Router) { }
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
 


  ngOnInit(): void {
    this.service.getAllDetails().subscribe(data => {
    this.excelDetails = data.body;
    console.log(data.body) 
});

//-------------------------------------------------for summary------------------------------------

  this.service.getAllDetails1().subscribe(data => {
  this.excelSumary1 = data.body;
  console.log(data.body) 
});


//---------------------------------------------------summary------------------------------------------


  }
  
  // alert("done");
    //this.router.navigate(['/app-company-create']);
    upload() {
      this.currentFileUpload = this.selectedFiles.item(0);
      this.service.pushFileToStorage(this.currentFileUpload).subscribe(event => {
       if (event instanceof HttpResponse) {
          console.log('File is completely uploaded!');
        }
      });
      this.selectedFiles = undefined;
    }

}
