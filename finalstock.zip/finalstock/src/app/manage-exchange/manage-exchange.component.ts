import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManageExchange } from 'src/entity/ManageExchange';
import { ManageExchangeService } from 'src/service/manage-exchange.service';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-manage-exchange',
  templateUrl: './manage-exchange.component.html',
  styleUrls: ['./manage-exchange.component.css']
})
export class ManageExchangeComponent implements OnInit {

  userDetails1:ManageExchange[];
  
  
  constructor(private service:ManageExchangeService, private router: Router) { }


  ngOnInit(): void {

    this.service.getAllCompanyDetails().subscribe(data => {
      this.userDetails1 = data.body;
      console.log(data.body)
 });


  }

  

}
