import { Component, OnInit } from '@angular/core';
import { CompanyDetailsModel } from 'src/entity/CompanyDetails';
import { CompanyDetailsService } from 'src/service/company-details.service';
import { FormGroup , FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { UpdateIPOComponent } from '../update-ipo/update-ipo.component';
import { UpdateIpoModel } from 'src/entity/UpdateIpoModel';
import { UpdateIpoService } from 'src/service/update-ipo.service';
@Component({
  selector: 'app-create-company',
  templateUrl: './create-company.component.html',
  styleUrls: ['./create-company.component.css']
})
export class CreateCompanyComponent implements OnInit {

  companyDetails:CompanyDetailsModel[];
  myForm3: FormGroup;
  constructor(private service:CompanyDetailsService, private router: Router, private service2: UpdateIpoService) { }

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data => {
      this.companyDetails = data.body;
      console.log(data.body)
 });

 {
  this.myForm3 = new FormGroup({
   companyname: new FormControl(''),
   ceoname: new FormControl(''),
   bod: new FormControl(''),
   turnover: new FormControl(''),
   description: new FormControl(''),
   sname: new FormControl(''),
   sector: new FormControl(''),
   scode: new FormControl(''),
   ipodate:new FormControl('')
  });

 }
  }
  onSubmit3(form: FormGroup){
    let CompanyDetails:CompanyDetailsModel={
     company_name : form.value.companyname,
     ceo : form.value.ceoname,
     board_of_directors : form.value.bod,
     turn_over : form.value.turnover,
     brief_about_companies : form.value.description,
     listed_in_stock_exchanges : form.value.sname,
     sector : form.value.sector,
     stock_code_in_each_stock_exchange : form.value.scode,
    };



    let ipoDetails:UpdateIpoModel ={
      company_name:form.value.cname,
    stock_exchange:'',
    price_per_share:null,
    total_number_of_shares:'',
    open_date_time:form.value.ipodate,
    remarks:''
    }
 
    this.service.saveCompanyDetails(CompanyDetails).subscribe(data =>{
      console.log(data.body);
    });

    this.service2.saveIpoDetails(ipoDetails).subscribe(data => {
      console.log(data.body);
    });

    this.router.navigate(['/manageCompany']);
  }

}
