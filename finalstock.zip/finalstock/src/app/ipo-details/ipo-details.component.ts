import { Component, OnInit } from '@angular/core';
import { UpdateIpoService } from 'src/service/update-ipo.service';
import { FormGroup, FormControl } from '@angular/forms';
import { UpdateIpoModel } from 'src/entity/UpdateIpoModel';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ipo-details',
  templateUrl: './ipo-details.component.html',
  styleUrls: ['./ipo-details.component.css']
})
export class IpoDetailsComponent implements OnInit {

  constructor(private router: Router,private service:UpdateIpoService) { }
  myForm4: FormGroup;
  ipoDetails:UpdateIpoModel[];
  ipo:UpdateIpoModel;

  ngOnInit(): void {
    this.service.getAllIpoDetails().subscribe(data => {
      this.ipoDetails = data.body;
      console.log(data.body)
 });
    {
      this.myForm4 = new FormGroup({
        name: new FormControl(''),
        
      });
  }
}
  onSubmit4(form: FormGroup){
  }
  submit2(ipo){
     window.localStorage.setItem('item3',JSON.stringify(ipo));
     this.router.navigate(['/updateIPO']);
  }
  title = 'SPB-Test3';
}

