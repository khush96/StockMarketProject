package com.vp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vp.model.User;
import com.vp.repository.SpringReadFileRepository;

@Service
@Transactional
public class CompanyUploadService {
    
	@Autowired
	SpringReadFileRepository companyDetailsRepository;
	
	public List<User> getAllCompanyDetails(){
		return (List<User>) companyDetailsRepository.findAll();
	}
	
	public void saveCompanyDetails(User companyDetails) {
		companyDetailsRepository.save(companyDetails);
	}

	
}