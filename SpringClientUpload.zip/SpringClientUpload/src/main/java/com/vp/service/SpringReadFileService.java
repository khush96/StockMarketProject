package com.vp.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.vp.model.User;

public interface SpringReadFileService {

	List<User> findAll();

	boolean saveDataFormUploadFile(MultipartFile file);

}
