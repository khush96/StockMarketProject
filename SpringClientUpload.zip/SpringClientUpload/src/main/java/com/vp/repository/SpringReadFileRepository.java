package com.vp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vp.model.User;
@Repository
public interface SpringReadFileRepository extends CrudRepository<User, Long> {

}
