package com.example.demo.model;

import org.springframework.stereotype.Component;

@Component
public class EmailId {
	
	String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
