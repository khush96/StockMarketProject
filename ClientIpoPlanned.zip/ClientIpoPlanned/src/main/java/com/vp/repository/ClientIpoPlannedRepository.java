package com.vp.repository;

import org.springframework.data.repository.CrudRepository;

import com.vp.model.ClientIpoPlanned;

public interface ClientIpoPlannedRepository extends CrudRepository<ClientIpoPlanned, Long> {

}
