package com.vp.repository;

import org.springframework.data.repository.CrudRepository;

import com.vp.model.CompanyDetails;

public interface CompanyDetailsRepository extends CrudRepository<CompanyDetails, Long>{

}
